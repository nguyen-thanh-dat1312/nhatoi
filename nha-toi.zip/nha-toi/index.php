<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
$siteDomain = "/";
$siteName = "/";
$version = "1a";
$json = file_get_contents("data/index.json");
$data = json_decode($json, true);
$time = (new DateTime())->format(DateTime::ATOM);

function formatPhone($phone, $pattern = 'xxxx.xxx.xxx') {
    $phone = preg_replace('/\D/', '', $phone);
    $i = 0;

    return preg_replace_callback('/x/', function () use ($phone, &$i) {
        return $phone[$i++] ?? '';
    }, $pattern);
}
?>
<!DOCTYPE html>
<html lang="vi">

<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>

<head>
    <meta charset="UTF-8"/>

    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>NhaToi | Đưa đặc sản núi rừng về tận ngõ ngách phố phường</title>
    <meta name="description" content="<?= $siteName ?> chuyên cung cấp sỉ và lẻ các sản phẩm từ thiên nhiên: hạt điều, mật ong, nấm linh chi cổ cò, chuối hột, sâm cau, chè dây rừng.">
    <meta name="robots" content="follow, index, max-snippet:-1, max-video-preview:-1, max-image-preview:large">
    <link rel="canonical" href="<?= $siteDomain ?>">
    <meta property="og:locale" content="vi_VN">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= $siteName ?> | Đưa đặc sản núi rừng về tận ngõ ngách phố phường">
    <meta property="og:description" content="<?= $siteName ?> luôn sẵn sàng chia sẽ đến các bạn những món ngon Tây Nguyên.">
    <meta property="og:url" content="<?= $siteDomain ?>">
    <meta property="og:site_name" content="<?= $siteName ?>">
    <meta property="og:updated_time" content="<?= $time ?>">
    <meta property="og:image" content="<?= $siteDomain ?>/logo.png?v=<?= $version ?>">
    <meta property="og:image:secure_url" content="<?= $siteDomain ?>/logo.png?v=<?= $version ?>">
    <meta property="og:image:width" content="512">
    <meta property="og:image:height" content="512">
    <meta property="og:image:alt" content="Logo <?= $siteName ?>">
    <meta property="og:image:type" content="image/png">
    <link rel="icon" href="/logo.png?v=<?= $version ?>">
    <link rel='prefetch' href='assets/js/flatsomece77.js?ver=22889b626eb7ec03b5a4'/>
    <link rel='prefetch' href='assets/js/chunk.slider.js?ver=3.20.0'/>

    <link rel='stylesheet' href='assets/css/flatsomec226.css?ver=3.20.0' type='text/css' media='all'/>
    <link rel='stylesheet' href='assets/css/style.css' type='text/css' media='all'/>

    <script type="text/javascript" src="assets/js/jquery.minf43b.js?ver=3.7.1" id="jquery-core-js"></script>
    <script type="text/javascript" src="assets/js/jquery-migrate.min5589.js?ver=3.4.1" id="jquery-migrate-js"></script>


</head>
<body class="home wp-singular page-template page-template-page-blank page-template-page-blank-php page page-id-14 wp-custom-logo wp-theme-flatsome wp-child-theme-flatsome-child theme-flatsome woocommerce-no-js woo-variation-swatches wvs-behavior-blur-no-cross wvs-theme-flatsome-child wvs-tooltip header-shadow lightbox nav-dropdown-has-arrow nav-dropdown-has-shadow nav-dropdown-has-border">

<div id="wrapper">

    <main id="main" class="">
        <div id="content" role="main" class="content-area">
            <div class="slider-wrapper relative" id="slider-468578840">
                <div class="slider slider-nav-circle slider-nav-large slider-nav-light slider-style-normal"
                     data-flickity-options='{
                     "cellAlign": "center",
                     "imagesLoaded": true,
                     "lazyLoad": 1,
                     "freeScroll": false,
                     "wrapAround": true,
                     "autoPlay": 6000,
                     "pauseAutoPlayOnHover" : true,
                     "prevNextButtons": true,
                     "contain" : true,
                     "adaptiveHeight" : true,
                     "dragThreshold" : 10,
                     "percentPosition": true,
                     "pageDots": true,
                     "rightToLeft": false,
                     "draggable": true,
                     "selectedAttraction": 0.1,
                     "parallax" : 0,
                     "friction": 0.6        }'
                >
                    <div class="banner has-hover" id="banner-1578065750">
                        <div class="banner-inner fill">
                            <div class="banner-bg fill">
                                <img fetchpriority="high" decoding="async" width="1920" height="1080" src="assets/images/banner.jpg" class="bg attachment-original size-original wvs-archive-product-image" alt="Banner hộp quà tết"/>
                            </div>
                            <div class="banner-layers container">
                                <div class="fill banner-link"></div>
                                <div id="text-box-1521183447" class="text-box banner-layer hidden x50 md-x50 lg-x50 y50 md-y50 lg-y50 res-text">
                                    <div class="text-box-content text dark">
                                        <div class="text-inner text-center">
                                            <div class="row" id="row-2069189837">
                                                <div id="col-1276739968" class="col medium-6 small-6 large-6">
                                                    <div class="col-inner">
                                                        <div id="text-2816694651" class="text">
                                                            <!-- <h3 class="uppercase"><strong>THỰC PHẨM SẠCH </strong></h3>
                                                            <h3 class="uppercase"><strong>TỪ THIÊN NHIÊN</strong></h3>
                                                            <p>Cam kết 100% tự nhiên</p>
                                                            <p>Freeship cho đơn hàng từ 500k</p> -->
                                                            <style>
                                                                #text-2816694651 {
                                                                    text-align: left;
                                                                }
                                                            </style>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="col-1107402536" class="col medium-6 small-6 large-6">
                                                    <div class="col-inner">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        #text-box-1521183447 {
                                            width: 94%;
                                        }

                                        #text-box-1521183447 .text-box-content {
                                            font-size: 100%;
                                        }
                                    </style>
                                </div>
                            </div>
                        </div>
                        <style>
                            #banner-1578065750 {
                                padding-top: 250px;
                            }

                            @media (min-width: 550px) {
                                #banner-1578065750 {
                                    padding-top: 41.66%;
                                }
                            }

                            @media (min-width: 850px) {
                                #banner-1578065750 {
                                    padding-top: 350px;
                                }
                            }
                        </style>
                    </div>
                </div>
                <div class="loading-spin dark large centered"></div>
            </div>
            <section class="section hide-for-small" id="section_779432585">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="row row-small" id="row-830247290">
                        <div id="col-1264881699" class="col medium-4 small-12 large-4">
                            <div class="col-inner">
                                <div class="icon-box featured-box icon-box-left text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img decoding="async" width="300" height="300" src="/assets/images/icon-1.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="assets/images/icon-1.png 300w, assets/images/icon-1.png 150w, assets/images/icon-1.png 100w, assets/images/icon-1.png 512w" sizes="(max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <h4>Từ núi đồi về tận nhà.</h4>
                                        <p>Đưa đặc sản núi rừng về tận ngõ ngách phố phường.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="col-269550567" class="col medium-4 small-12 large-4">
                            <div class="col-inner">
                                <div class="icon-box featured-box icon-box-left text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img decoding="async" width="300" height="300" src="/assets/images/icon-2.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="/assets/images/icon-2.png 300w, /assets/images/icon-2.png 150w, /assets/images/icon-2.png 100w, /assets/images/icon-2.png 512w" sizes="(max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <h4>Nhatoi có gì, nhà bạn có đấy.</h4>
                                        <p>Nhatoi luôn sẵn sàng chia sẽ đến các bạn những món ngon Tây Nguyên.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="col-1163779285" class="col medium-4 small-12 large-4">
                            <div class="col-inner">
                                <div class="icon-box featured-box icon-box-left text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img loading="lazy" decoding="async" width="300" height="300" src="/assets/images/icon-3.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="/assets/images/icon-3.png 300w, /assets/images/icon-3.png 150w, /assets/images/icon-3.png 100w, /assets/images/icon-3.png 512w" sizes="auto, (max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <h4>Sỉ và lẻ luôn sẵn sàng.</h4>
                                        <p>Từ khâu thu hoạch đến đóng gói.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <style>
                    #section_779432585 {
                        padding-top: 30px;
                        padding-bottom: 30px;
                    }
                </style>
            </section>
            <section class="section show-for-small" id="section_1151007183">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="row row-small" id="row-57051090">
                        <div id="col-1571504514" class="col medium-4 small-4 large-4">
                            <div class="col-inner text-center">
                                <div class="icon-box featured-box icon-box-top text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img decoding="async" width="300" height="300" src="assets/images/icon-1.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="assets/images/icon-1.png 300w, assets/images/icon-1.png 150w, assets/images/icon-1.png 100w, assets/images/icon-1.png 512w" sizes="(max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <div id="text-3799115252" class="text">
                                            <h4>Từ núi đồi về tận nhà.</h4>
                                            <style>
                                                #text-3799115252 {
                                                    font-size: 0.8rem;
                                                    text-align: center;
                                                }
                                            </style>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="col-184142071" class="col medium-4 small-4 large-4">
                            <div class="col-inner text-center">
                                <div class="icon-box featured-box icon-box-top text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img decoding="async" width="300" height="300" src="assets/images/icon-2.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="assets/images/icon-2.png 300w, assets/images/icon-2.png 150w, assets/images/icon-2.png 100w, assets/images/icon-2.png 512w" sizes="(max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <div id="text-3101404325" class="text">
                                            <h4>Nhatoi có gì, nhà bạn có đấy.</h4>
                                            <style>
                                                #text-3101404325 {
                                                    font-size: 0.8rem;
                                                    text-align: center;
                                                }
                                            </style>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="col-1182426248" class="col medium-4 small-4 large-4">
                            <div class="col-inner text-center">
                                <div class="icon-box featured-box icon-box-top text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img loading="lazy" decoding="async" width="300" height="300" src="assets/images/icon-3.png" class="attachment-medium size-medium wvs-archive-product-image" alt=""
                                                     srcset="assets/images/icon-3.png 300w, assets/images/icon-3.png 150w, assets/images/icon-3.png 100w, assets/images/icon-3.png 512w" sizes="auto, (max-width: 300px) 100vw, 300px"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <div id="text-1235306600" class="text">
                                            <h4>Sỉ và lẻ luôn sẵn sàng.</h4>
                                            <style>
                                                #text-1235306600 {
                                                    font-size: 0.8rem;
                                                    text-align: center;
                                                }
                                            </style>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <style>
                    #section_1151007183 {
                        padding-top: 30px;
                        padding-bottom: 30px;
                    }
                </style>
            </section>
            <section class="section" id="section_364921833">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="container section-title-container">
                        <h2 class="section-title section-title-center"><b aria-hidden="true"></b><span class="section-title-main">NHATOI sẵn có</span><b aria-hidden="true"></b></h2>
                    </div>
                    <div class="row  equalize-box large-columns-4 medium-columns-3 small-columns-2 row-small has-shadow row-box-shadow-2 row-box-shadow-1-hover slider row-slider slider-nav-circle slider-nav-outside slider-nav-push"
                         data-flickity-options='{&quot;imagesLoaded&quot;: true, &quot;groupCells&quot;: &quot;100%&quot;, &quot;dragThreshold&quot; : 5, &quot;cellAlign&quot;: &quot;left&quot;,&quot;wrapAround&quot;: true,&quot;prevNextButtons&quot;: true,&quot;percentPosition&quot;: true,&quot;pageDots&quot;: false, &quot;rightToLeft&quot;: false, &quot;autoPlay&quot; : 4000}'>
                        <?php foreach ($data['san_co'] as $item): ?>
                            <div class="product-small col has-hover wvs-archive-product-wrapper product type-product post-460 status-publish first instock product_cat-hat-dinh-duong has-post-thumbnail shipping-taxable purchasable product-type-variable has-default-attributes">
                                <div class="col-inner">
                                    <div class="product-small box ">
                                        <div class="box-image">
                                            <div class="image-none">
                                                <a href="javascript:void(0)">
                                                    <img loading="lazy" decoding="async" width="300" height="300" src="assets/images/<?= $item['image'] ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail wvs-archive-product-image" alt="Hạt điều rang muối vỏ lụa Bình Phước 500gr"
                                                         srcset="assets/images/<?= $item['image'] ?> 300w,  assets/images/<?= $item['image'] ?> 1024w, assets/images/<?= $item['image'] ?> 150w, assets/images/<?= $item['image'] ?> 768w, assets/images/<?= $item['image'] ?> 600w, assets/images/<?= $item['image'] ?> 100w, assets/images/<?= $item['image'] ?> 50w, assets/images/<?= $item['image'] ?> 1200w"
                                                         sizes="auto, (max-width: 300px) 100vw, 300px"/> </a>
                                            </div>
                                            <div class="image-tools is-small top right show-on-hover">
                                            </div>
                                            <div class="image-tools is-small hide-for-small bottom left show-on-hover">
                                            </div>
                                            <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                            </div>
                                        </div>
                                        <div class="box-text box-text-products">
                                            <div class="title-wrapper">
                                                <p class="name product-title woocommerce-loop-product__title"><a href="javascript:void(0)" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?= $item['title'] ?></a></p>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        <?php endforeach; ?>

                    </div>
                </div>

            </section>
            <section class="section">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="container section-title-container">
                        <h2 class="section-title section-title-center"><b aria-hidden="true"></b><span class="section-title-main">Hạt điều</span><b aria-hidden="true"></b></h2>
                    </div>
                    <div class="row  equalize-box large-columns-4 medium-columns-3 small-columns-2 row-small has-shadow row-box-shadow-2 row-box-shadow-1-hover">
                        <?php foreach ($data['hat_dieu'] as $item): ?>
                            <div class="col">
                                <div class="col-inner">
                                    <div class="badge-container absolute left top z-1">
                                    </div>
                                    <div class="product-small box has-hover box-normal box-text-bottom">
                                        <div class="box-image">
                                            <div class="">
                                                <a href="javascript:void(0)" aria-label="<?= $item['title'] ?>">
                                                    <img loading="lazy" decoding="async" width="1200" height="1200" src="assets/images/<?= $item['image'] ?>" class="attachment-original size-original wvs-archive-product-image" alt="<?= $item['title'] ?>"
                                                         srcset="assets/images/<?= $item['image'] ?> 1200w, assets/images/<?= $item['image'] ?> 300w,assets/images/<?= $item['image'] ?> 1024w,assets/images/<?= $item['image'] ?> 150w,assets/images/<?= $item['image'] ?> 768w, assets/images/<?= $item['image'] ?> 600w, assets/images/<?= $item['image'] ?> 100w, assets/images/<?= $item['image'] ?> 50w"
                                                         sizes="auto, (max-width: 1200px) 100vw, 1200px"/> </a>
                                            </div>
                                            <div class="image-tools top right show-on-hover">
                                            </div>
                                            <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                            </div>
                                        </div>
                                        <div class="box-text text-left">
                                            <div class="title-wrapper">
                                                <p class="name product-title woocommerce-loop-product__title"><a href="javascript:void(0)" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?= $item['title'] ?></a></p>
                                            </div>
                                            <div class="price-wrapper">
                                                <p> Liên hệ: <a href="tel:<?= $item['contact'] ?>"><?= formatPhone($item['contact']) ?></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>

            </section>

            <section class="section">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="container section-title-container">
                        <h2 class="section-title section-title-center"><b aria-hidden="true"></b><span class="section-title-main">Đặc sản núi rừng tây nguyên</span><b aria-hidden="true"></b></h2>
                    </div>
                    <div class="row  equalize-box large-columns-4 medium-columns-3 small-columns-2 row-small has-shadow row-box-shadow-2 row-box-shadow-1-hover">
                        <?php foreach ($data['dac_san_tay_nguyen'] as $item): ?>
                            <div class="col">
                                <div class="col-inner">
                                    <div class="badge-container absolute left top z-1">
                                    </div>
                                    <div class="product-small box has-hover box-normal box-text-bottom">
                                        <div class="box-image">
                                            <div class="">
                                                <a href="javascript:void(0)" aria-label="<?= $item['title'] ?>">
                                                    <img loading="lazy" decoding="async" width="1200" height="1200" src="assets/images/<?= $item['image'] ?>" class="attachment-original size-original wvs-archive-product-image" alt="<?= $item['title'] ?>"
                                                         srcset="assets/images/<?= $item['image'] ?> 1200w, assets/images/<?= $item['image'] ?> 300w,assets/images/<?= $item['image'] ?> 1024w,assets/images/<?= $item['image'] ?> 150w,assets/images/<?= $item['image'] ?> 768w, assets/images/<?= $item['image'] ?> 600w, assets/images/<?= $item['image'] ?> 100w, assets/images/<?= $item['image'] ?> 50w"
                                                         sizes="auto, (max-width: 1200px) 100vw, 1200px"/> </a>
                                            </div>
                                            <div class="image-tools top right show-on-hover">
                                            </div>
                                            <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                            </div>
                                        </div>
                                        <div class="box-text text-left">
                                            <div class="title-wrapper">
                                                <p class="name product-title woocommerce-loop-product__title"><a href="javascript:void(0)" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?= $item['title'] ?></a></p>
                                            </div>
                                            <div class="price-wrapper">
                                                <p> Liên hệ: <a href="tel:<?= $item['contact'] ?>"><?= formatPhone($item['contact']) ?></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>

            </section>

            <section class="section">
                <div class="section-bg fill">
                </div>
                <div class="section-content relative">
                    <div class="container section-title-container">
                        <h2 class="section-title section-title-center"><b aria-hidden="true"></b><span class="section-title-main">Từ xứ nghệ</span><b aria-hidden="true"></b></h2>
                    </div>
                    <div class="row  equalize-box large-columns-4 medium-columns-3 small-columns-2 row-small has-shadow row-box-shadow-2 row-box-shadow-1-hover">
                        <?php foreach ($data['xu_nghe'] as $item): ?>
                            <div class="col">
                                <div class="col-inner">
                                    <div class="badge-container absolute left top z-1">
                                    </div>
                                    <div class="product-small box has-hover box-normal box-text-bottom">
                                        <div class="box-image">
                                            <div class="">
                                                <a href="javascript:void(0)" aria-label="<?= $item['title'] ?>">
                                                    <img loading="lazy" decoding="async" width="1200" height="1200" src="assets/images/<?= $item['image'] ?>" class="attachment-original size-original wvs-archive-product-image" alt="<?= $item['title'] ?>"
                                                         srcset="assets/images/<?= $item['image'] ?> 1200w, assets/images/<?= $item['image'] ?> 300w,assets/images/<?= $item['image'] ?> 1024w,assets/images/<?= $item['image'] ?> 150w,assets/images/<?= $item['image'] ?> 768w, assets/images/<?= $item['image'] ?> 600w, assets/images/<?= $item['image'] ?> 100w, assets/images/<?= $item['image'] ?> 50w"
                                                         sizes="auto, (max-width: 1200px) 100vw, 1200px"/> </a>
                                            </div>
                                            <div class="image-tools top right show-on-hover">
                                            </div>
                                            <div class="image-tools grid-tools text-center hide-for-small bottom hover-slide-in show-on-hover">
                                            </div>
                                        </div>
                                        <div class="box-text text-left">
                                            <div class="title-wrapper">
                                                <p class="name product-title woocommerce-loop-product__title"><a href="javascript:void(0)" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?= $item['title'] ?></a></p>
                                            </div>
                                            <div class="price-wrapper">
                                                <p> Liên hệ: <a href="tel:<?= $item['contact'] ?>"><?= formatPhone($item['contact']) ?></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>

            </section>
        </div>
    </main>
    <footer id="footer" class="footer-wrapper">
        <section class="section hide-for-small" id="section_1386745115">
            <div class="bg section-bg fill bg-fill  bg-loaded">
                <div class="is-border" style="border-color:rgb(136, 95, 40);border-width:1px 0px 0px 0px;">
                </div>
            </div>
            <div class="section-content relative">
                <div class="row row-small" id="row-1537895969">
                    <div id="col-1519467566" class="col medium-3 small-6 large-3">
                        <div class="col-inner">
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1193566700">
                                <div class="img-inner dark">
                                    <img src="/logo.png?v=<?= $version ?>" class="attachment-original size-original wvs-archive-product-image" alt="Logo <?= $siteName ?>" decoding="async" loading="lazy" sizes="auto, (max-width: 1876px) 100vw, 1876px"
                                         style="cursor: pointer;width: 98px; height: 98px;">
                                </div>
                            </div>
                            <p>NhaToi nơi gửi gắm, chia sẽ yêu thương qua những món ngon nơi núi rừng đến ngõ ngách phố phường!</p>
                        </div>
                    </div>
                    <div id="col-998281539" class="col medium-3 small-6 large-3">
                        <div class="col-inner">
                            <h4 style="text-align: left;"><span style="color: #000000;"><strong>THÔNG TIN LIÊN HỆ</strong></span></h4>
                            <p style="text-align: left;"><span style="color: #000000;">Địa chỉ: CC Citisoho, 35CL, Phường Cát Lái - Thành phố Hồ Chí Minh</span></p>
                            <p style="text-align: left;"><span style="color: #000000;">Hotline: <a href="tel:0966545804" target="_blank">0966.545.804</a></span></p>
                            <p style="text-align: left;"><span style="color: #000000;">Email: kidskillcare@gmail.com</span></p>
                        </div>
                    </div>
                    <div id="col-1722761854" class="col medium-3 small-6 large-3">
                        <div class="col-inner">
                            <h4>
                                <font color="#000000"><span style="caret-color: rgb(0, 0, 0);">FANPAGE</span></font>
                            </h4>
                            <div class="ux-menu stack stack-col justify-start ux-menu--divider-solid">
                                <div class="ux-menu-link flex menu-item">
                                </div>
                                <div class="ux-menu-link flex menu-item">
                                    <a class="ux-menu-link__link flex" href="https://www.youtube.com/@lexnguyen6586" style="cursor: pointer;" target="_self">Kênh YouTube cá nhân.</a></div>
                                <div class="ux-menu-link flex menu-item">
                                </div>
                                <div class="ux-menu-link flex menu-item">
                                </div>
                                <div class="ux-menu-link flex menu-item">
                                </div>
                                <div class="ux-menu-link flex menu-item">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="col-452240593" class="col medium-3 small-6 large-3">
                        <div class="col-inner">
                            <h4><span style="color: #000000;"></span></h4>
                            <div id="fb-root" class=" fb_reset">
                                <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
                                    <div></div>
                                </div>
                            </div>
                            <p></p>
                            <div id="gap-2107776195" class="gap-element clearfix" style="display:block; height:auto;">
                            </div>
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1583868271">
                                <a class="" href="http://online.gov.vn/Home/WebDetails/137172" style="cursor: pointer;">
                                    <div class="img-inner dark">
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section show-for-small" id="section_20829317">
            <div class="bg section-bg fill bg-fill  bg-loaded">
                <div class="is-border" style="border-color:rgb(136, 95, 40);border-width:1px 0px 0px 0px;">
                </div>
            </div>
            <div class="section-content relative">
                <div class="row row-small" id="row-400878123">
                    <div id="col-196920849" class="col small-12 large-12">
                        <div class="col-inner">
                            <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_484670408">
                                <div class="img-inner dark">
                                    <img width="1876" height="1876" src="logo.png?v=<?= $version ?>" class="attachment-original size-original wvs-archive-product-image" alt="Logo <?= $siteName ?>" decoding="async" loading="lazy" sizes="auto, (max-width: 1876px) 100vw, 1876px"
                                         style="cursor: pointer;">
                                </div>
                            </div>
                            <p>NhaToi nơi gửi gắm, chia sẽ yêu thương qua những món ngon núi rừng đến ngõ ngách phố phường!</p>
                        </div>
                    </div>
                    <div id="col-1723913638" class="col small-12 large-12">
                        <div class="col-inner">
                            <h4 style="text-align: justify;"><span style="color: #000000;">THÔNG TIN LIÊN HỆ</span></h4>
                            <p style="text-align: justify;"><span style="color: #000000;">Địa chỉ: CC Citisoho, 35CL, Phường Cát Lái - Thành phố Hồ Chí Minh</span></p>
                            <p style="text-align: justify;"><span style="color: #000000;">Hotline: <a href="tel:0966545804" target="_blank">0966.545.804</a></span></p>
                            <p style="text-align: justify;"><span style="color: #000000;">Email: kidskillcare@gmail.com</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="absolute-footer dark medium-text-center text-center">
            <div class="container clearfix">
                <div class="footer-primary pull-left">
                    <div class="copyright-footer">
                        Copyright 2026 © <b>NhaToi</b></div>
                </div>
            </div>
        </div>

    </footer>
</div>


<script type="text/javascript" id="flatsome-js-js-extra">
    /* <![CDATA[ */
    var flatsomeVars = {
        "theme": {"version": "3.20.0"},
        "ajaxurl": " ",
        "rtl": "",
        "sticky_height": "73",
        "stickyHeaderHeight": "0",
        "scrollPaddingTop": "0",
        "assets_url": "/assets/",
        "lightbox": {
            "close_markup": "\u003Cbutton title=\"%title%\" type=\"button\" class=\"mfp-close\"\u003E\u003Csvg xmlns=\"http://www.w3.org/2000/svg\" width=\"28\" height=\"28\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"\u003E\u003Cline x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"\u003E\u003C/line\u003E\u003Cline x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"\u003E\u003C/line\u003E\u003C/svg\u003E\u003C/button\u003E",
            "close_btn_inside": false
        },
        "user": {"can_edit_pages": false},
        "i18n": {"mainMenu": "Menu ch\u00ednh", "toggleButton": "Chuy\u1ec3n \u0111\u1ed5i"},
        "options": {
            "cookie_notice_version": "1",
            "swatches_layout": false,
            "swatches_disable_deselect": false,
            "swatches_box_select_event": false,
            "swatches_box_behavior_selected": false,
            "swatches_box_update_urls": "1",
            "swatches_box_reset": false,
            "swatches_box_reset_limited": false,
            "swatches_box_reset_extent": false,
            "swatches_box_reset_time": 300,
            "search_result_latency": "0",
            "header_nav_vertical_fly_out_frontpage": 1
        },
        "is_mini_cart_reveal": "1"
    };
    //# sourceURL=flatsome-js-js-extra
    /* ]]> */
</script>
<script type="text/javascript" src="assets/js/flatsomece77.js?ver=22889b626eb7ec03b5a4" id="flatsome-js-js"></script>
<script type="text/javascript" src="assets/js/woocommerce1867.js?ver=1c9be63d628ff7c3ff4c" id="flatsome-theme-woocommerce-js-js"></script>
</body>
</html>
